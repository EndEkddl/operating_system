#include "userprog/syscall.h"
#include <stdio.h>
#include <syscall-nr.h>
#include "userprog/syscall.h"
#include "userprog/process.h"
#include "threads/interrupt.h"
#include "threads/thread.h"
#include "threads/vaddr.h"
#include "devices/shutdown.h"
#include "devices/input.h"
#include "filesys/off_t.h"
#include "filesys/filesys.h"
#include "threads/synch.h"
#include "filesys/file.h" // not sure
#include <string.h> // not sure

#define max(a,b) (((a) > (b)) ? (a) : (b))
struct semaphore semaWrt;
struct semaphore semaRd;

static void syscall_handler (struct intr_frame *);
void isMemoryValid(void *addr);

void
syscall_init (void) 
{
  intr_register_int (0x30, 3, INTR_ON, syscall_handler, "syscall");
}

static void
syscall_handler (struct intr_frame *f UNUSED) 
{
	void *syscallNum = (f->esp);
	void *token1, *token2, *token3, *token4;

	isMemoryValid(syscallNum+3);

	switch(*(int *)syscallNum){
		case SYS_HALT: halt(); break;
		case SYS_EXIT: {
						   token1 = f->esp + 4;
						   isMemoryValid(token1+3);
						   exit(*(int *)token1);
						   break;
					   }
		case SYS_EXEC: {
						   token1 = f->esp +4;
						   isMemoryValid(token1+3);
						   f->eax = (uint32_t)exec( (char *)*(int*)token1 );
						   break;
					   }
		case SYS_WAIT: {
						   token1 = f->esp +4;
						   isMemoryValid(token1+3);
						   f->eax = (uint32_t)process_wait(*(int *)token1);
							break;
					   }
		case SYS_READ: {
						   token1 = f->esp +4;
						   token2 = f->esp +8;
						   token3 = f->esp + 12;
						   isMemoryValid(token3 + 3);
						   f->eax = read(*(int *)token1, *(void **)token2, *(unsigned int *)token3);
						   break;
					   }
		case SYS_WRITE:{
						   token1 = f->esp +4;
						   token2 = f->esp +8;
						   token3 = f->esp + 12;
						   isMemoryValid(token3 + 3);
						   f->eax = write(*(int *)token1, *(void **)token2, *(unsigned int *)token3);
						   
						   break;
					   }
		case SYS_FIBO: {
						   token1 = f->esp +4;
						   isMemoryValid(token1 + 3);
						   f->eax = fibonacci(*(int *)token1);
						   break;
					   }
		case SYS_MAXINT: {
							
						   token1 = f->esp +4;
						   token2 = f->esp +8;
						   token3 = f->esp +12;
						   token4 = f->esp +16;
						   isMemoryValid(token4 + 3);
						   f->eax = max_of_four_int(*(int *)token1, *(int *)token2, *(int *)token3, *(int *)token4);
						   break;
					   }
		case SYS_CREATE: {
							token1 = f->esp + 4;
							token2 = f->esp + 8;
							isMemoryValid(token2+3);
							f->eax = create((char *)*(int *)token1, *(unsigned int*)token2);
							break;
						 }
		case SYS_REMOVE: {
							token1 = f->esp + 4;
							isMemoryValid(token1+3);
							f->eax = remove((char *)*(int *)token1);
							break;
						 }
		case SYS_OPEN: {
							token1 = f->esp + 4;
							isMemoryValid(token1+3);
							f->eax = open((char *)*(int *)token1);
						    break;
					   }
		case SYS_CLOSE: {
							token1 = f->esp + 4;
							isMemoryValid(token1+3);
							close(*(int *)token1);
							break;
						}
		case SYS_FILESIZE: {
								token1 = f->esp + 4;
								isMemoryValid(token1+3);
								f->eax = filesize(*(int *)token1);
							    break;
						   }
		case SYS_TELL: {
							token1 = f->esp + 4;
							isMemoryValid(token1+3);
							f->eax = tell(*(int *)token1);
							break;
						
					   }
		case SYS_SEEK: {
							token1 = f->esp + 4;
							token2 = f->esp + 8;
							isMemoryValid(token2+3);
							seek(*(int *)token1, *(unsigned *)token2);
							break;
					   }
		default : break;
	}
  
}

void halt(){
	shutdown_power_off();
	return;
}
void exit(int status){
	struct thread *curr = thread_current();
	curr->exit_status = status;

	char name[31];
	int i;

	memset(name, 0x00, sizeof(name));

	int len = strlen(curr->name);
	for(i=0; i<len; i++){
		if(curr->name[i] == '\0' || curr->name[i] == ' ') break;

		name[i] = curr->name[i];
	}
	name[i] = '\0';

	for(i=0; i<128; i++){
		if(curr->info[i].fp != NULL){
			close(curr->info[i].fd);
		}
	}

	printf("%s: exit(%d)\n", name, curr->exit_status);
	thread_exit();

}

pid_t exec(const char *cmd_line){
	return process_execute(cmd_line);
}

int wait(pid_t pid){
	return process_wait(pid);
}

int read(int fd, void *buffer, unsigned size){
	char tmp; int i;
	struct thread* curr = thread_current();

	if(!is_user_vaddr(buffer) || !is_user_vaddr(buffer+size-1)) {
		exit(-1);
	}

	if(fd == 0){
		lock_acquire(&file_lock);
		for(i=0; i<size; i++){
			tmp = input_getc();
			*(unsigned char*)(buffer+i) = tmp;

			if(tmp == '\0' || tmp == '\n'){
				*((char *)(buffer+i)) = '\0';
				break;
			}
		}
		lock_release(&file_lock);
		return i;
	}
	else if(fd > 2){
		int res;
		lock_acquire(&file_lock);
		for(i=0; i<128; i++){
			if(curr->info[i].fd == fd){
		//		lock_acquire(&file_lock);
				res = file_read(curr->info[i].fp, buffer, size);
				lock_release(&file_lock);
				return res;
			}
		}
		lock_release(&file_lock);
		exit(-1);
	}
	else return -1;
}

int write(int fd, const void *buffer, unsigned size){
	int i;
	struct thread* curr = thread_current();

	if(fd == 1){
	   putbuf(buffer, size);
	   return size;
	}
	else if(fd > 2){
		int res;
		lock_acquire(&file_lock);
		for(i=0; i<128; i++){
			if(curr->info[i].fd == fd){
	//			lock_acquire(&file_lock);
				res = file_write(curr->info[i].fp, buffer, size);
				lock_release(&file_lock);
				return res;
			}
		}
		lock_release(&file_lock);
		exit(-1);
	}
	else return -1;
}

int fibonacci(int n){
	int x=1, y=1, tmp;
	if(n == 1 || n == 2) return 1;

	for(int i=3; i<=n; i++){
		tmp = x;
		x = y;
		y = y + tmp;
	}

	return y;
}

int max_of_four_int(int a, int b, int c, int d){

	return max(a, max(b, max(c, d)));
}

void isMemoryValid(void *addr){
	if(addr < 0x08048000 || addr >= PHYS_BASE) {
		exit(-1);
	}

	return;
}

bool create(const char *file, unsigned init_size){

	if(file == NULL) exit(-1);
	return filesys_create(file, init_size);
}

bool remove(const char *file){
	if(file == NULL) exit(-1);
	return filesys_remove(file);
}

int open(const char *file){

	static int cnt = 2;
	struct file *fp;
	struct thread* curr = thread_current();

	if(file == NULL) return -1;

	cnt++;

	lock_acquire(&file_lock);
	fp = filesys_open(file);
	lock_release(&file_lock);

	if(fp == NULL) return -1;
	else {
		for(int i=0; i<128; i++){
			if(curr->info[i].fp == NULL){
				curr->info[i].fp = fp;
				curr->info[i].fd = cnt;
				return cnt;
			}
		}
		return -1;
	}

}

int filesize(int fd){

	struct thread* curr = thread_current();

	for(int i=0; i<128; i++){
		if(curr->info[i].fd == fd){
			if(curr->info[i].fp == NULL) exit(-1);

			return file_length(curr->info[i].fp);
		}
	}
}

void seek(int fd, unsigned position){
	
	struct thread* curr = thread_current();
	
	for(int i=0; i<128; i++){
		if(curr->info[i].fd == fd){
			if(curr->info[i].fp == NULL) exit(-1);

			file_seek(curr->info[i].fp, position);
		}
	}
}

unsigned tell(int fd){
	
	struct thread* curr = thread_current();
	
	for(int i=0; i<128; i++){
		if(curr->info[i].fd == fd){
			if(curr->info[i].fp == NULL) exit(-1);

			return file_tell(curr->info[i].fp);
		}
	}
}

void close(int fd){
	struct file* fp;
	struct thread* curr = thread_current();

	for(int i=0; i<128; i++){
		if(curr->info[i].fd == fd){
			if(curr->info[i].fp == NULL) exit(-1);

			fp = curr->info[i].fp;
			curr->info[i].fp = NULL;
			file_close(fp);
		}
	}
}
